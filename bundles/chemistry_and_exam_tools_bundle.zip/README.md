# Chemistry & Exam Tools Bundle — TI-84 Plus CE Python

6 standalone TI-84 Plus CE **Python Edition** programs for General/Intro Chemistry, plus
general practice-exam time management tools useful in any STEM course.

## What's Included

| File | What it does |
|---|---|
| `ideal_gas_law.py` | Ideal Gas Law solver (P, V, n, or T) plus a Combined Gas Law (state 1 → state 2) solver. |
| `stoichiometry_molar_mass.py` | Molar mass calculator from element counts, plus mass ↔ moles conversion. |
| `unit_converter.py` | Menu-driven unit converter: length, mass, pressure, temperature, energy. |
| `formula_flashcards.py` | Self-quiz flashcards: random formula-name recall drill by subject category. **Self-study only.** |
| `exam_countdown_drill.py` | Countdown timer plus a random mental-math/sanity-check practice drill with answer checking. |
| `acid_base_calculator.py` | pH/pOH from [H+] or [OH-] (and back), plus Henderson-Hasselbalch buffer pH. |

> **Note on `formula_flashcards.py`:** this is a self-study memorization aid only — it is a
> recall drill, not an answer-lookup tool, and must not be used during an actual exam.

## Installing on Your Calculator (TI Connect™ CE)

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — it should detect your connected calculator in "Calculator Explorer."
4. For each `.py` file in this bundle: drag and drop the file onto the Calculator Explorer window
   (or use **Actions → Send to Calculator**). TI Connect CE automatically converts the `.py` source
   file into the calculator's native Python AppVar format and installs it into the Python App.
5. On the calculator, open the **Python App**, find the program by name in the on-calculator program
   list, and select **Run**.

You can also skip the computer entirely and type any of these programs directly into the
on-calculator Python editor — they're short, plain-text files.

Keep an eye on the ~50 KB / 100-program on-device storage limit; archive or delete programs you're
not actively using to free up space.

## ⚠️ Exam Policy Disclaimer — Read This First

**Many standardized and proctored exams — AP Exams, the FE/PE exams, and many university
midterms/finals — explicitly prohibit calculators that have been loaded with stored notes,
formulas, or "quiz" programs.** Some exams require you to clear your calculator's memory or use
exam mode (e.g. TI's Press-to-Test) before you're allowed to bring it into the room.

**Before bringing any of these programs into a real exam, you MUST verify your specific exam's
calculator and program policy with your instructor or exam administrator.** These tools are
intended strictly as **study and practice aids** for homework, practice exams, and self-review —
they are **not** intended to help with, and must not be used to facilitate, cheating or misconduct
on a live/proctored exam. The `formula_flashcards.py` program in particular repeats this same
warning in its own header/prompts. When in doubt, delete or archive these programs (or reset your
calculator to defaults) before any exam where their presence would violate the rules.
