# Complete Toolkit — TI-84 Plus CE Python

**All 52 programs.** Every subject bundle, nothing held back, in one download.

This is the whole library: the seven subject bundles combined, with the one program that
sells into two of them (`chi_square_genetics.py`) included once rather than twice.

## What's Included

| Bundle | Programs | Covers |
|---|---|---|
| **Algebra, Precalculus & Trigonometry** | 11 | Quadratics and vertex form, complex arithmetic, linear systems, matrices, polynomial and rational analysis, sequences and series, logs and exponentials, oblique triangles, the unit circle, 2D/3D geometry |
| **Calculus & Differential Equations** | 6 | Numeric derivatives, Simpson's rule integration, Taylor/Maclaurin series, Newton-Raphson, two-sided limits, first-order ODEs by Euler and Heun |
| **Statistics, Probability & Discrete Math** | 5 | Descriptive statistics, confidence intervals and hypothesis tests, permutations/combinations/binomial probability, chi-square goodness of fit, base conversion and truth tables |
| **Physics & Engineering** | 13 | SUVAT and projectiles, 2D statics and 3D vectors, Ohm's law and RLC circuits, Bernoulli and Reynolds, calorimetry, ideal-gas processes, Carnot cycles, stress/strain, thermal expansion, orbital mechanics |
| **Chemistry & Exam Tools** | 7 | Ideal and combined gas laws, molar mass and stoichiometry, pH/pOH and buffers, reaction kinetics, unit conversion, formula recall drills, a countdown timer |
| **Biology & Lab Science** | 6 | Punnett squares, Hardy-Weinberg, chi-square genetics, exponential and logistic population growth, dilutions and serial dilutions, surface-area-to-volume scaling |
| **Finance & Business Math** | 5 | Time value of money, loan amortization, compound interest and APR/APY, NPV/IRR/payback, break-even and margins |

Seven bundles listing 53 slots, minus the one shared program, is **52 distinct programs**.

## Folder layout

Because this download holds the whole library, the `py/` and `8xv/` folders are split
into subject subfolders rather than being flat:

```
py/calculus/derivative_numeric.py       8xv/calculus/DERIV.8xv
py/finance/tvm_solver.py                8xv/finance/TVM.8xv
...
```

## What's in This Download

Every program is included **twice**, in two formats. You only need one of them:

```
8xv/   ready-to-install Python AppVars  <- drag these onto TI Connect CE, no conversion needed
py/    the plain-text Python source     <- read it, edit it, or type it in by hand
```

The `.8xv` files are the same programs, already converted into the calculator's native Python
AppVar format. Each one is named after the name it will show up as in the Python App's program
list, so `QUAD.8xv` installs as `QUAD`.

| Program | On-calculator name | Ready-to-install file |
|---|---|---|
| `algebra_linear_stats/quadratic_solver.py` | `QUAD` | `8xv/algebra_linear_stats/QUAD.8xv` |
| `algebra_linear_stats/quadratic_vertex_analyzer.py` | `VERTEX` | `8xv/algebra_linear_stats/VERTEX.8xv` |
| `algebra_linear_stats/complex_number_calculator.py` | `CMPLX` | `8xv/algebra_linear_stats/CMPLX.8xv` |
| `algebra_linear_stats/linear_system_solver.py` | `LINSOLV` | `8xv/algebra_linear_stats/LINSOLV.8xv` |
| `algebra_linear_stats/matrix_toolkit.py` | `MATRIX` | `8xv/algebra_linear_stats/MATRIX.8xv` |
| `precalculus/polynomial_analyzer.py` | `POLYFUNC` | `8xv/precalculus/POLYFUNC.8xv` |
| `precalculus/sequences_series.py` | `SEQSER` | `8xv/precalculus/SEQSER.8xv` |
| `precalculus/log_exp_solver.py` | `LOGEXP` | `8xv/precalculus/LOGEXP.8xv` |
| `trigonometry/oblique_triangle_solver.py` | `TRIG` | `8xv/trigonometry/TRIG.8xv` |
| `trigonometry/unit_circle_reference.py` | `UNITCIRC` | `8xv/trigonometry/UNITCIRC.8xv` |
| `geometry/shape_geometry_solver.py` | `GEOM` | `8xv/geometry/GEOM.8xv` |
| `calculus/derivative_numeric.py` | `DERIV` | `8xv/calculus/DERIV.8xv` |
| `calculus/simpsons_rule.py` | `SIMPSON` | `8xv/calculus/SIMPSON.8xv` |
| `calculus/taylor_series.py` | `TAYLOR` | `8xv/calculus/TAYLOR.8xv` |
| `calculus/newton_raphson.py` | `NEWTON` | `8xv/calculus/NEWTON.8xv` |
| `calculus/limit_evaluator.py` | `LIMIT` | `8xv/calculus/LIMIT.8xv` |
| `differential_equations/ode_solver_euler.py` | `ODE` | `8xv/differential_equations/ODE.8xv` |
| `algebra_linear_stats/descriptive_stats.py` | `STATS` | `8xv/algebra_linear_stats/STATS.8xv` |
| `algebra_linear_stats/confidence_interval_hypothesis_test.py` | `CONFINT` | `8xv/algebra_linear_stats/CONFINT.8xv` |
| `algebra_linear_stats/combinatorics_probability.py` | `COMBIN` | `8xv/algebra_linear_stats/COMBIN.8xv` |
| `biology/chi_square_genetics.py` | `CHISQ` | `8xv/biology/CHISQ.8xv` |
| `computer_science/discrete_math_toolkit.py` | `DISCRT` | `8xv/computer_science/DISCRT.8xv` |
| `physics_engineering/kinematics_solver.py` | `SUVAT` | `8xv/physics_engineering/SUVAT.8xv` |
| `physics_engineering/projectile_motion.py` | `PROJ` | `8xv/physics_engineering/PROJ.8xv` |
| `physics_engineering/statics_vectors.py` | `STATIC` | `8xv/physics_engineering/STATIC.8xv` |
| `physics_engineering/vector3d_toolkit.py` | `VECT3D` | `8xv/physics_engineering/VECT3D.8xv` |
| `physics_engineering/ohms_law_circuits.py` | `OHMS` | `8xv/physics_engineering/OHMS.8xv` |
| `physics_engineering/rlc_impedance.py` | `RLC` | `8xv/physics_engineering/RLC.8xv` |
| `physics_engineering/fluid_mechanics_solver.py` | `FLUID` | `8xv/physics_engineering/FLUID.8xv` |
| `physics_engineering/heat_transfer_calculator.py` | `HEAT` | `8xv/physics_engineering/HEAT.8xv` |
| `thermo_materials/ideal_gas_processes.py` | `GASPROC` | `8xv/thermo_materials/GASPROC.8xv` |
| `thermo_materials/carnot_efficiency.py` | `CARNOT` | `8xv/thermo_materials/CARNOT.8xv` |
| `thermo_materials/stress_strain.py` | `STRESS` | `8xv/thermo_materials/STRESS.8xv` |
| `thermo_materials/thermal_expansion.py` | `EXPAND` | `8xv/thermo_materials/EXPAND.8xv` |
| `astronomy/orbital_mechanics_calculator.py` | `ORBIT` | `8xv/astronomy/ORBIT.8xv` |
| `chemistry_and_exam_tools/ideal_gas_law.py` | `GASLAW` | `8xv/chemistry_and_exam_tools/GASLAW.8xv` |
| `chemistry_and_exam_tools/stoichiometry_molar_mass.py` | `MOLAR` | `8xv/chemistry_and_exam_tools/MOLAR.8xv` |
| `chemistry_and_exam_tools/acid_base_calculator.py` | `PH` | `8xv/chemistry_and_exam_tools/PH.8xv` |
| `chemistry_and_exam_tools/reaction_kinetics.py` | `KINETIC` | `8xv/chemistry_and_exam_tools/KINETIC.8xv` |
| `chemistry_and_exam_tools/unit_converter.py` | `UNITS` | `8xv/chemistry_and_exam_tools/UNITS.8xv` |
| `chemistry_and_exam_tools/formula_flashcards.py` | `CARDS` | `8xv/chemistry_and_exam_tools/CARDS.8xv` |
| `chemistry_and_exam_tools/exam_countdown_drill.py` | `DRILL` | `8xv/chemistry_and_exam_tools/DRILL.8xv` |
| `biology/punnett_square_solver.py` | `PUNNET` | `8xv/biology/PUNNET.8xv` |
| `biology/hardy_weinberg.py` | `HARDYW` | `8xv/biology/HARDYW.8xv` |
| `biology/population_growth.py` | `POPGROW` | `8xv/biology/POPGROW.8xv` |
| `biology/dilution_calculator.py` | `DILUTION` | `8xv/biology/DILUTION.8xv` |
| `biology/surface_area_volume.py` | `SAVOL` | `8xv/biology/SAVOL.8xv` |
| `finance/tvm_solver.py` | `TVM` | `8xv/finance/TVM.8xv` |
| `finance/loan_amortization.py` | `LOAN` | `8xv/finance/LOAN.8xv` |
| `finance/compound_interest.py` | `INTEREST` | `8xv/finance/INTEREST.8xv` |
| `finance/npv_irr.py` | `NPVIRR` | `8xv/finance/NPVIRR.8xv` |
| `finance/break_even_margin.py` | `BREAKEVN` | `8xv/finance/BREAKEVN.8xv` |

## ⚠️ You cannot fit all 52 on the calculator at once

The complete library is roughly **243 KB** of Python AppVars, and a TI-84 Plus CE Python
holds only about **50 KB** of Python across at most 100 programs. That is by design: this
is a library to install *from*, a course at a time, not a single payload to dump onto the
device.

In practice: install the subject folder you need this semester, and archive or delete it
when the course ends. The largest single subject folder is comfortably inside the limit,
so any one course's set fits with room to spare. Keep this ZIP — it is your backup, and
you will want it after any Press-to-Test or memory reset (see below).

## ⚠️ Before You Buy a Calculator — Check for "Python"

**These programs require a TI-84 Plus CE _Python Edition_, or a TI-84 Plus CE that has TI's
Python App installed.** A TI-84 Plus CE without Python cannot run them at all.

This matters more than it used to. Texas Instruments **discontinued the TI-84 Plus CE Python on
2026-04-27**, and the plain TI-84 Plus CE that TI currently sells does **not** include Python.
TI has named the **TI-84 Evo** as the successor model. So a calculator bought new today under
the "TI-84 Plus CE" name may well be a unit that cannot run these programs.

Before you buy hardware:

- Look for the word **"Python"** printed on the calculator's faceplate or bezel.
- Or switch the calculator on and check that a **Python** app appears in the Apps list.
- If you already own a TI-84 Plus CE without Python, check TI's site for the Python App for your
  model and OS version before assuming these will run.

**TI-84 Evo compatibility is not yet confirmed.** We have not tested these programs on that model
and make no claim either way about whether they run on it.

These programs do **not** run on the TI-83 Plus, the monochrome TI-84 Plus, the TI-84 Plus Silver
Edition, the TI-Nspire family, or any Casio or HP calculator.

## Installing on Your Calculator (TI Connect™ CE)

First, the part that's the same either way:

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — your calculator should appear in **Calculator Explorer**.

### Option A — send the ready-made `.8xv` files (fewest steps)

4. Open this bundle's `8xv/` folder, select the files you want (or all of them), and drag them onto
   the Calculator Explorer window — or use **Actions → Send to Calculator**. There's no conversion
   step: these are already Python AppVars.
5. On the calculator, open the **Python App**, pick the program from the list, and select **Run**.

### Option B — send the `.py` source and let TI Connect CE convert it

4. Do exactly the same thing, but drag the files from the `py/` folder instead. TI Connect CE
   converts each `.py` file into a Python AppVar itself as it sends.
5. Open the **Python App**, pick the program, and select **Run**.

Option B uses TI's own converter, so it's the fallback if anything about Option A doesn't work on
your setup. Both produce the same program on the calculator.

### Option C — no computer at all

Open the **Python App** on the calculator, create a new program, and type the source in from the
`py/` folder. These are short, plain-text files, so this is slower but perfectly workable.

### A note on the `.8xv` files

The `.8xv` files were generated with an open-source converter (included in the project repo as
`tools/py_to_8xv.py`) rather than by TI Connect CE itself. Every file is checked byte-for-byte
against the format TI's own software produces, and the converter is validated by reproducing a
TI-generated Python AppVar exactly. If you ever hit a file that won't load, use Option B — the
`.py` source in this bundle is the same program and always works through TI's own converter.

Keep an eye on the ~50 KB / 100-program on-device storage limit; archive or delete programs you're
not actively using to free up space.

## ⚠️ Back Up Before Press-to-Test — It Deletes These Programs

**Entering Press-to-Test (exam mode) deletes the programs in this bundle. They do not come back.**

TI documents that entering Press-to-Test deletes *"All variables stored in RAM and in archived
memory,"* and TI's Press-to-Test Guidebook states that *"Other variables stored in RAM and in
archived memory (including AppVars) are deleted."* Python programs on the TI-84 Plus CE Python are
stored as Python AppVars. Unlike Apps and TI-BASIC programs — which Press-to-Test only *disables*
and then restores when you exit exam mode — **these are deleted outright and are not restored.**

A full **All-Memory reset** does the same thing, and additionally removes the Python App itself,
which then has to be re-installed with TI Connect™ CE before any of these will run.

**The workaround, which takes about two minutes:**

1. **Before** entering Press-to-Test or resetting memory, connect the calculator and copy this
   bundle's files somewhere safe — your computer, or just keep this ZIP.
2. Enter exam mode and sit your exam with a clean calculator.
3. Afterwards, exit exam mode and re-send the `.8xv` (or `.py`) files exactly as you did when you
   first installed them.

Your download stays available in your account, so you can always re-install from scratch — but
keeping a local copy saves you the trip. Being able to strip the calculator for a proctored exam
and restore it in two minutes is arguably a feature, not a bug.

## ⚠️ Exam Policy Disclaimer — Read Before Test Day

**You are responsible for knowing your own exam's calculator rules.** They differ significantly
between exams, and they change. Here is where things stood as of 2026-08-12 — verify current
policy yourself before any exam. **Nothing in this bundle is "approved" for any exam:** no exam
board operates an approval process for third-party calculator software.

**AP® Exams (College Board).** The TI-84 Plus CE Python Edition appears on College Board's list of
approved handheld graphing calculators. College Board's published AP calculator policy states:
*"You don't need to clear your calculators' memories before or after the exam,"* and *"Calculators
with built-in physical constants, metric conversions, and physics, chemistry, or mathematics
formulas are permitted."* College Board approves the *calculator*; it does not approve, review, or
endorse third-party programs. Note also that College Board prohibits using calculator memory to
remove test material from the exam room, and that AP® Calculus and AP® Precalculus both have
sections where no calculator is allowed at all. Confirm current policy with your AP® coordinator:
<https://apstudents.collegeboard.org/exam-policies-guidelines/calculator-policies>

**SAT®, PSAT/NMSQT®, PSAT™ 10, PSAT™ 8/9.** College Board requires you to *"remove programs that
have algebra functionality"* and *"remove any stored documents,"* and the Testing Rules state that
*"Before testing, you will be asked to clear all saved formulas on a calculator you bring."*
**Remove these programs before an SAT® Suite test.**
<https://satsuite.collegeboard.org/sat/what-to-bring-do/calculator-policy>

**ACT® (and ACT® WorkKeys® Applied Math).** ACT requires all documents to be removed, and permits
only single-purpose math programs of **25 logical lines or fewer**. Most programs in this bundle
exceed that. ACT also states that putting the calculator in Press-to-Test mode is *not* sufficient
— the programs must actually be removed. **Remove these programs before the ACT®.**
<https://www.act.org/content/act/en/products-and-services/the-act/test-day/calculator-policy.html>

**NCEES® FE / PE / FS / PS exams.** The TI-84 is **prohibited outright** — not because of what is
stored on it, but because the model itself is not permitted. NCEES allows only Casio fx-115 and
fx-991 models, HP 33s and HP 35s, and Texas Instruments models whose name contains "TI-30X" or
"TI-36X". If you are sitting the FE or PE, use a TI-36X Pro or a Casio fx-991 — these programs
cannot be used there in any form. <https://ncees.org/exams/>

**IB® Diploma Programme.** The TI-84 Plus CE Python is a permitted non-CAS device, but IB requires
that third-party programs and stored notes be removed (via reset) or blocked (via examination
mode), and schools must clear calculator memories. **Remove or block these programs for IB® exams.**

**CLEP®.** You may not bring your own calculator at all; CLEP provides an on-screen TI-84 Plus CE
for its Calculus and Precalculus exams.

**University and course exams.** Your instructor or department sets the rules. Many require a
memory clear or TI's Press-to-Test mode. **Ask before test day.**

### These are study tools

This bundle is intended for homework, practice problems, self-review, and practice exams. It is
**not** intended to help with, and must not be used to facilitate, cheating or academic misconduct
on any exam. `formula_flashcards.py`, where included, is a self-quiz recall drill, not an
answer-lookup tool. Where a program's presence would break your exam's rules, delete it or use
exam mode — and back it up first, as described above.

---

AP®, Advanced Placement®, SAT®, PSAT™, and CLEP® are trademarks registered by the College Board,
which is not affiliated with, and does not endorse, this product. PSAT/NMSQT® is a registered
trademark of the College Board and the National Merit Scholarship Corporation, which are not
affiliated with, and do not endorse, this product. ACT® and WorkKeys® are registered trademarks of
ACT Education Corp., which is not affiliated with, and does not endorse, this product. IB® and
International Baccalaureate® are registered trademarks of the International Baccalaureate
Organization, which is not affiliated with, and does not endorse, this product. NCEES® is a
registered trademark of the National Council of Examiners for Engineering and Surveying, which is
not affiliated with, and does not endorse, this product. TI-84 Plus CE Python™, TI Connect™ CE,
and Texas Instruments® are trademarks of Texas Instruments Incorporated, which is not affiliated
with, and does not endorse, this product. All trademarks are the property of their respective
owners. Exam policies are subject to change; verify current policy with the relevant exam
authority.
