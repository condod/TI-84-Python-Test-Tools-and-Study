# Physics / Engineering Bundle — TI-84 Plus CE Python

6 standalone TI-84 Plus CE **Python Edition** programs for Physics I/II (mechanics, circuits),
Statics, and Circuits/Engineering fundamentals.

## What's Included

| File | What it does |
|---|---|
| `kinematics_solver.py` | SUVAT kinematics solver: pick the unknown of v0, v, a, t, d and enter the other four. |
| `projectile_motion.py` | Projectile motion: range, max height, time of flight, with optional `ti_plotlib` trajectory plot. |
| `ohms_law_circuits.py` | Ohm's Law/power solver plus a series/parallel resistor combiner. |
| `rlc_impedance.py` | Series RLC impedance magnitude/phase and LC resonant frequency calculator. |
| `statics_vectors.py` | Resultant of 2D force vectors, and 2D torque/moment about a point. |
| `vector3d_toolkit.py` | 3D vector toolkit: dot product, cross product, magnitude, angle between vectors, and projection. |

## Installing on Your Calculator (TI Connect™ CE)

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — it should detect your connected calculator in "Calculator Explorer."
4. For each `.py` file in this bundle: drag and drop the file onto the Calculator Explorer window
   (or use **Actions → Send to Calculator**). TI Connect CE automatically converts the `.py` source
   file into the calculator's native Python AppVar format and installs it into the Python App.
5. On the calculator, open the **Python App**, find the program by name in the on-calculator program
   list, and select **Run**.

You can also skip the computer entirely and type any of these programs directly into the
on-calculator Python editor — they're short, plain-text files.

Keep an eye on the ~50 KB / 100-program on-device storage limit; archive or delete programs you're
not actively using to free up space.

## ⚠️ Exam Policy Disclaimer — Read This First

**Many standardized and proctored exams — AP Exams, the FE/PE exams, and many university
midterms/finals — explicitly prohibit calculators that have been loaded with stored notes,
formulas, or "quiz" programs.** Some exams require you to clear your calculator's memory or use
exam mode (e.g. TI's Press-to-Test) before you're allowed to bring it into the room.

**Before bringing any of these programs into a real exam, you MUST verify your specific exam's
calculator and program policy with your instructor or exam administrator.** These tools are
intended strictly as **study and practice aids** for homework, practice exams, and self-review —
they are **not** intended to help with, and must not be used to facilitate, cheating or misconduct
on a live/proctored exam. When in doubt, delete or archive these programs (or reset your
calculator to defaults) before any exam where their presence would violate the rules.
