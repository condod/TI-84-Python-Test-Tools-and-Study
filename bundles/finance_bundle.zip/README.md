# Finance & Business Math Bundle — TI-84 Plus CE Python

5 standalone TI-84 Plus CE **Python Edition** programs that turn a TI-84 into a
financial calculator — the time-value-of-money and capital-budgeting work that a
BA II Plus normally gets bought for.

## What's Included

| File | What it does |
|---|---|
| `tvm_solver.py` | The standard five-variable time-value-of-money solver: give any four of PV, FV, PMT, N and rate and it finds the fifth, with end-of-period (ordinary annuity) or begin-of-period (annuity due) payments. The rate is found by bisection, which cannot diverge the way Newton's method can on an awkward cash flow, and zero-rate cases are handled by their limits. A 200,000 loan at 0.5%/month over 360 months returns the textbook 1,199.10 payment. |
| `loan_amortization.py` | Level payment from amount, rate, term and payments per year, then a full payment-by-payment schedule (paused every 12 rows), a year-by-year summary, or totals only. Shows how paying extra shortens the loan, and says so when a payment does not cover the first month's interest instead of looping forever. |
| `compound_interest.py` | Future value at any compounding frequency including continuous, the interest earned, the effective annual rate, APR ↔ APY conversion, and a head-to-head comparison of two accounts ranked honestly by APY. |
| `npv_irr.py` | NPV at your discount rate with an accept/reject reading, IRR by bisection, simple and discounted payback interpolated within the crossing period, and the profitability index — for up to 40 cash flows. Counts sign changes and warns when multiple IRRs may exist, or says plainly when there is no IRR at all. Optional NPV-vs-rate table from 0% to 30%. |
| `break_even_margin.py` | Break-even in units and revenue, contribution margin and its ratio, the volume needed to hit a target profit, margin of safety against expected sales, and margin ↔ markup conversion in both directions. Explains when no volume ever breaks even rather than returning a negative quantity. |

**Course fit:** Personal Finance, Business Math, Finance 101, Corporate Finance,
Accounting, Economics, and Engineering Economics.

## What's in This Download

Every program is included **twice**, in two formats. You only need one of them:

```
8xv/   ready-to-install Python AppVars  <- drag these onto TI Connect CE, no conversion needed
py/    the plain-text Python source     <- read it, edit it, or type it in by hand
```

The `.8xv` files are the same programs, already converted into the calculator's native Python
AppVar format. Each one is named after the name it will show up as in the Python App's program
list, so `QUAD.8xv` installs as `QUAD`.

| Program | On-calculator name | Ready-to-install file |
|---|---|---|
| `tvm_solver.py` | `TVM` | `8xv/TVM.8xv` |
| `loan_amortization.py` | `LOAN` | `8xv/LOAN.8xv` |
| `compound_interest.py` | `INTEREST` | `8xv/INTEREST.8xv` |
| `npv_irr.py` | `NPVIRR` | `8xv/NPVIRR.8xv` |
| `break_even_margin.py` | `BREAKEVN` | `8xv/BREAKEVN.8xv` |

## ⚠️ Before You Buy a Calculator — Check for "Python"

**These programs require a TI-84 Plus CE _Python Edition_, or a TI-84 Plus CE that has TI's
Python App installed.** A TI-84 Plus CE without Python cannot run them at all.

This matters more than it used to. Texas Instruments **discontinued the TI-84 Plus CE Python on
2026-04-27**, and the plain TI-84 Plus CE that TI currently sells does **not** include Python.
TI has named the **TI-84 Evo** as the successor model. So a calculator bought new today under
the "TI-84 Plus CE" name may well be a unit that cannot run these programs.

Before you buy hardware:

- Look for the word **"Python"** printed on the calculator's faceplate or bezel.
- Or switch the calculator on and check that a **Python** app appears in the Apps list.
- If you already own a TI-84 Plus CE without Python, check TI's site for the Python App for your
  model and OS version before assuming these will run.

**TI-84 Evo compatibility is not yet confirmed.** We have not tested these programs on that model
and make no claim either way about whether they run on it.

These programs do **not** run on the TI-83 Plus, the monochrome TI-84 Plus, the TI-84 Plus Silver
Edition, the TI-Nspire family, or any Casio or HP calculator.

## Installing on Your Calculator (TI Connect™ CE)

First, the part that's the same either way:

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — your calculator should appear in **Calculator Explorer**.

### Option A — send the ready-made `.8xv` files (fewest steps)

4. Open this bundle's `8xv/` folder, select the files you want (or all of them), and drag them onto
   the Calculator Explorer window — or use **Actions → Send to Calculator**. There's no conversion
   step: these are already Python AppVars.
5. On the calculator, open the **Python App**, pick the program from the list, and select **Run**.

### Option B — send the `.py` source and let TI Connect CE convert it

4. Do exactly the same thing, but drag the files from the `py/` folder instead. TI Connect CE
   converts each `.py` file into a Python AppVar itself as it sends.
5. Open the **Python App**, pick the program, and select **Run**.

Option B uses TI's own converter, so it's the fallback if anything about Option A doesn't work on
your setup. Both produce the same program on the calculator.

### Option C — no computer at all

Open the **Python App** on the calculator, create a new program, and type the source in from the
`py/` folder. These are short, plain-text files, so this is slower but perfectly workable.

### A note on the `.8xv` files

The `.8xv` files were generated with an open-source converter (included in the project repo as
`tools/py_to_8xv.py`) rather than by TI Connect CE itself. Every file is checked byte-for-byte
against the format TI's own software produces, and the converter is validated by reproducing a
TI-generated Python AppVar exactly. If you ever hit a file that won't load, use Option B — the
`.py` source in this bundle is the same program and always works through TI's own converter.

Keep an eye on the ~50 KB / 100-program on-device storage limit; archive or delete programs you're
not actively using to free up space.

## ⚠️ Back Up Before Press-to-Test — It Deletes These Programs

**Entering Press-to-Test (exam mode) deletes the programs in this bundle. They do not come back.**

TI documents that entering Press-to-Test deletes *"All variables stored in RAM and in archived
memory,"* and TI's Press-to-Test Guidebook states that *"Other variables stored in RAM and in
archived memory (including AppVars) are deleted."* Python programs on the TI-84 Plus CE Python are
stored as Python AppVars. Unlike Apps and TI-BASIC programs — which Press-to-Test only *disables*
and then restores when you exit exam mode — **these are deleted outright and are not restored.**

A full **All-Memory reset** does the same thing, and additionally removes the Python App itself,
which then has to be re-installed with TI Connect™ CE before any of these will run.

**The workaround, which takes about two minutes:**

1. **Before** entering Press-to-Test or resetting memory, connect the calculator and copy this
   bundle's files somewhere safe — your computer, or just keep this ZIP.
2. Enter exam mode and sit your exam with a clean calculator.
3. Afterwards, exit exam mode and re-send the `.8xv` (or `.py`) files exactly as you did when you
   first installed them.

Your download stays available in your account, so you can always re-install from scratch — but
keeping a local copy saves you the trip. Being able to strip the calculator for a proctored exam
and restore it in two minutes is arguably a feature, not a bug.

## ⚠️ Exam Policy Disclaimer — Read Before Test Day

**You are responsible for knowing your own exam's calculator rules.** They differ significantly
between exams, and they change. Here is where things stood as of 2026-08-12 — verify current
policy yourself before any exam. **Nothing in this bundle is "approved" for any exam:** no exam
board operates an approval process for third-party calculator software.

**AP® Exams (College Board).** The TI-84 Plus CE Python Edition appears on College Board's list of
approved handheld graphing calculators. College Board's published AP calculator policy states:
*"You don't need to clear your calculators' memories before or after the exam,"* and *"Calculators
with built-in physical constants, metric conversions, and physics, chemistry, or mathematics
formulas are permitted."* College Board approves the *calculator*; it does not approve, review, or
endorse third-party programs. Note also that College Board prohibits using calculator memory to
remove test material from the exam room, and that AP® Calculus and AP® Precalculus both have
sections where no calculator is allowed at all. Confirm current policy with your AP® coordinator:
<https://apstudents.collegeboard.org/exam-policies-guidelines/calculator-policies>

**SAT®, PSAT/NMSQT®, PSAT™ 10, PSAT™ 8/9.** College Board requires you to *"remove programs that
have algebra functionality"* and *"remove any stored documents,"* and the Testing Rules state that
*"Before testing, you will be asked to clear all saved formulas on a calculator you bring."*
**Remove these programs before an SAT® Suite test.**
<https://satsuite.collegeboard.org/sat/what-to-bring-do/calculator-policy>

**ACT® (and ACT® WorkKeys® Applied Math).** ACT requires all documents to be removed, and permits
only single-purpose math programs of **25 logical lines or fewer**. Most programs in this bundle
exceed that. ACT also states that putting the calculator in Press-to-Test mode is *not* sufficient
— the programs must actually be removed. **Remove these programs before the ACT®.**
<https://www.act.org/content/act/en/products-and-services/the-act/test-day/calculator-policy.html>

**NCEES® FE / PE / FS / PS exams.** The TI-84 is **prohibited outright** — not because of what is
stored on it, but because the model itself is not permitted. NCEES allows only Casio fx-115 and
fx-991 models, HP 33s and HP 35s, and Texas Instruments models whose name contains "TI-30X" or
"TI-36X". If you are sitting the FE or PE, use a TI-36X Pro or a Casio fx-991 — these programs
cannot be used there in any form. <https://ncees.org/exams/>

**IB® Diploma Programme.** The TI-84 Plus CE Python is a permitted non-CAS device, but IB requires
that third-party programs and stored notes be removed (via reset) or blocked (via examination
mode), and schools must clear calculator memories. **Remove or block these programs for IB® exams.**

**CLEP®.** You may not bring your own calculator at all; CLEP provides an on-screen TI-84 Plus CE
for its Calculus and Precalculus exams.

**University and course exams.** Your instructor or department sets the rules. Many require a
memory clear or TI's Press-to-Test mode. **Ask before test day.**

### These are study tools

This bundle is intended for homework, practice problems, self-review, and practice exams. It is
**not** intended to help with, and must not be used to facilitate, cheating or academic misconduct
on any exam. `formula_flashcards.py`, where included, is a self-quiz recall drill, not an
answer-lookup tool. Where a program's presence would break your exam's rules, delete it or use
exam mode — and back it up first, as described above.

---

AP®, Advanced Placement®, SAT®, PSAT™, and CLEP® are trademarks registered by the College Board,
which is not affiliated with, and does not endorse, this product. PSAT/NMSQT® is a registered
trademark of the College Board and the National Merit Scholarship Corporation, which are not
affiliated with, and do not endorse, this product. ACT® and WorkKeys® are registered trademarks of
ACT Education Corp., which is not affiliated with, and does not endorse, this product. IB® and
International Baccalaureate® are registered trademarks of the International Baccalaureate
Organization, which is not affiliated with, and does not endorse, this product. NCEES® is a
registered trademark of the National Council of Examiners for Engineering and Surveying, which is
not affiliated with, and does not endorse, this product. TI-84 Plus CE Python™, TI Connect™ CE,
and Texas Instruments® are trademarks of Texas Instruments Incorporated, which is not affiliated
with, and does not endorse, this product. All trademarks are the property of their respective
owners. Exam policies are subject to change; verify current policy with the relevant exam
authority.
