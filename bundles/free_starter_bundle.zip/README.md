# Free Starter Bundle — TI-84 Plus CE Python

A free taste of the full toolkit: 3 essential, broadly-useful TI-84 Plus CE **Python Edition**
programs that work for almost any math/science class. Install these in a few minutes and see
what the paid subject bundles and the Complete Toolkit offer.

## What's Included

| File | What it does |
|---|---|
| `unit_converter.py` | Menu-driven unit converter: length, mass, pressure, temperature, energy. Useful in nearly every science and engineering course. |
| `quadratic_solver.py` | Quadratic equation solver with discriminant classification and real/complex roots (`a ± bi`). A staple of Algebra I/II and beyond. |
| `descriptive_stats.py` | Mean, median, mode, min/max/range, sample & population variance/standard deviation from a data list. Handy for Stats, labs, and data analysis. |

Like it? The full paid lineup includes 4 subject bundles (Calculus & Differential Equations,
Algebra/Linear Algebra/Stats, Physics/Engineering, and Chemistry & Exam Tools) plus a
**Complete Toolkit** bundle with all 20+ programs and the full reference README — see the
main `bundles/` folder and `PRICING.md` for details.

## Installing on Your Calculator (TI Connect™ CE)

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — it should detect your connected calculator in "Calculator Explorer."
4. For each `.py` file in this bundle: drag and drop the file onto the Calculator Explorer window
   (or use **Actions → Send to Calculator**). TI Connect CE automatically converts the `.py` source
   file into the calculator's native Python AppVar format and installs it into the Python App.
5. On the calculator, open the **Python App**, find the program by name in the on-calculator program
   list, and select **Run**.

You can also skip the computer entirely and type any of these programs directly into the
on-calculator Python editor — they're short, plain-text files.

## ⚠️ Exam Policy Disclaimer — Read This First

**Many standardized and proctored exams — AP Exams, the FE/PE exams, and many university
midterms/finals — explicitly prohibit calculators that have been loaded with stored notes,
formulas, or "quiz" programs.** Some exams require you to clear your calculator's memory or use
exam mode (e.g. TI's Press-to-Test) before you're allowed to bring it into the room.

**Before bringing any of these programs into a real exam, you MUST verify your specific exam's
calculator and program policy with your instructor or exam administrator.** These tools are
intended strictly as **study and practice aids** for homework, practice exams, and self-review —
they are **not** intended to help with, and must not be used to facilitate, cheating or misconduct
on a live/proctored exam. When in doubt, delete or archive these programs (or reset your
calculator to defaults) before any exam where their presence would violate the rules.
