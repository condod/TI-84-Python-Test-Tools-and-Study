# Calculus & Differential Equations Bundle — TI-84 Plus CE Python

6 standalone TI-84 Plus CE **Python Edition** programs for Calculus I/II/III and
introductory Differential Equations / numerical methods.

## What's Included

| File | What it does |
|---|---|
| `derivative_numeric.py` | Numeric derivative approximator using the central-difference formula with adjustable step size. Enter `f(x)`, a point `x0`, and a step size `h`; outputs derivative estimates at `h/10`, `h`, and `h*10` so you can see the estimate stabilize. |
| `simpsons_rule.py` | Definite integral approximator using composite Simpson's Rule. Enter `f(x)`, bounds `a`/`b`, and a subinterval count `n`. |
| `taylor_series.py` | Maclaurin/Taylor series term generator & partial-sum approximator for sin, cos, e^x, and ln(1+x), compared against the calculator's exact `math` value. |
| `newton_raphson.py` | Newton-Raphson root finder with a full iteration table (derivative estimated numerically). |
| `limit_evaluator.py` | Numeric limit evaluator: evaluates `f(x)` approaching a target value from both sides and reports a best-guess limit. |
| `ode_solver_euler.py` | First-order ODE numerical solver for `dy/dx = f(x,y)` using Euler's method or Improved Euler (Heun's method), with a step-by-step table. |

All calculus programs that need a function of `x` (or `x,y`) let you type it as a
plain string, e.g. `sin(x)+x**2` or `exp(-x)`.

## What's in This Download

Every program is included **twice**, in two formats. You only need one of them:

```
8xv/   ready-to-install Python AppVars  <- drag these onto TI Connect CE, no conversion needed
py/    the plain-text Python source     <- read it, edit it, or type it in by hand
```

The `.8xv` files are the same programs, already converted into the calculator's native Python
AppVar format. Each one is named after the name it will show up as in the Python App's program
list, so `QUADSOLV.8xv` installs as `QUADSOLV`.

| Program | On-calculator name | Ready-to-install file |
|---|---|---|
| `derivative_numeric.py` | `DERIVNUM` | `8xv/DERIVNUM.8xv` |
| `simpsons_rule.py` | `SIMPSON` | `8xv/SIMPSON.8xv` |
| `taylor_series.py` | `TAYLOR` | `8xv/TAYLOR.8xv` |
| `newton_raphson.py` | `NEWTRAPH` | `8xv/NEWTRAPH.8xv` |
| `limit_evaluator.py` | `LIMITEVL` | `8xv/LIMITEVL.8xv` |
| `ode_solver_euler.py` | `ODEEULER` | `8xv/ODEEULER.8xv` |

## Installing on Your Calculator (TI Connect™ CE)

First, the part that's the same either way:

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — your calculator should appear in **Calculator Explorer**.

### Option A — send the ready-made `.8xv` files (fewest steps)

4. Open this bundle's `8xv/` folder, select the files you want (or all of them), and drag them onto
   the Calculator Explorer window — or use **Actions → Send to Calculator**. There's no conversion
   step: these are already Python AppVars.
5. On the calculator, open the **Python App**, pick the program from the list, and select **Run**.

### Option B — send the `.py` source and let TI Connect CE convert it

4. Do exactly the same thing, but drag the files from the `py/` folder instead. TI Connect CE
   converts each `.py` file into a Python AppVar itself as it sends.
5. Open the **Python App**, pick the program, and select **Run**.

Option B uses TI's own converter, so it's the fallback if anything about Option A doesn't work on
your setup. Both produce the same program on the calculator.

### Option C — no computer at all

Open the **Python App** on the calculator, create a new program, and type the source in from the
`py/` folder. These are short, plain-text files, so this is slower but perfectly workable.

### A note on the `.8xv` files

The `.8xv` files were generated with an open-source converter (included in the project repo as
`tools/py_to_8xv.py`) rather than by TI Connect CE itself. Every file is checked byte-for-byte
against the format TI's own software produces, and the converter is validated by reproducing a
TI-generated Python AppVar exactly. If you ever hit a file that won't load, use Option B — the
`.py` source in this bundle is the same program and always works through TI's own converter.

Keep an eye on the ~50 KB / 100-program on-device storage limit; archive or delete programs you're
not actively using to free up space.

## ⚠️ Exam Policy Disclaimer — Read This First

**Many standardized and proctored exams — AP Exams, the FE/PE exams, and many university
midterms/finals — explicitly prohibit calculators that have been loaded with stored notes,
formulas, or "quiz" programs.** Some exams require you to clear your calculator's memory or use
exam mode (e.g. TI's Press-to-Test) before you're allowed to bring it into the room.

**Before bringing any of these programs into a real exam, you MUST verify your specific exam's
calculator and program policy with your instructor or exam administrator.** These tools are
intended strictly as **study and practice aids** for homework, practice exams, and self-review —
they are **not** intended to help with, and must not be used to facilitate, cheating or misconduct
on a live/proctored exam. When in doubt, delete or archive these programs (or reset your
calculator to defaults) before any exam where their presence would violate the rules.
