# Calculus & Differential Equations Bundle — TI-84 Plus CE Python

6 standalone TI-84 Plus CE **Python Edition** programs for Calculus I/II/III and
introductory Differential Equations / numerical methods.

## What's Included

| File | What it does |
|---|---|
| `derivative_numeric.py` | Numeric derivative approximator using the central-difference formula with adjustable step size. Enter `f(x)`, a point `x0`, and a step size `h`; outputs derivative estimates at `h/10`, `h`, and `h*10` so you can see the estimate stabilize. |
| `simpsons_rule.py` | Definite integral approximator using composite Simpson's Rule. Enter `f(x)`, bounds `a`/`b`, and a subinterval count `n`. |
| `taylor_series.py` | Maclaurin/Taylor series term generator & partial-sum approximator for sin, cos, e^x, and ln(1+x), compared against the calculator's exact `math` value. |
| `newton_raphson.py` | Newton-Raphson root finder with a full iteration table (derivative estimated numerically). |
| `limit_evaluator.py` | Numeric limit evaluator: evaluates `f(x)` approaching a target value from both sides and reports a best-guess limit. |
| `ode_solver_euler.py` | First-order ODE numerical solver for `dy/dx = f(x,y)` using Euler's method or Improved Euler (Heun's method), with a step-by-step table. |

All calculus programs that need a function of `x` (or `x,y`) let you type it as a
plain string, e.g. `sin(x)+x**2` or `exp(-x)`.

## Installing on Your Calculator (TI Connect™ CE)

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — it should detect your connected calculator in "Calculator Explorer."
4. For each `.py` file in this bundle: drag and drop the file onto the Calculator Explorer window
   (or use **Actions → Send to Calculator**). TI Connect CE automatically converts the `.py` source
   file into the calculator's native Python AppVar format and installs it into the Python App.
5. On the calculator, open the **Python App**, find the program by name in the on-calculator program
   list, and select **Run**.

You can also skip the computer entirely and type any of these programs directly into the
on-calculator Python editor — they're short, plain-text files.

Keep an eye on the ~50 KB / 100-program on-device storage limit; archive or delete programs you're
not actively using to free up space.

## ⚠️ Exam Policy Disclaimer — Read This First

**Many standardized and proctored exams — AP Exams, the FE/PE exams, and many university
midterms/finals — explicitly prohibit calculators that have been loaded with stored notes,
formulas, or "quiz" programs.** Some exams require you to clear your calculator's memory or use
exam mode (e.g. TI's Press-to-Test) before you're allowed to bring it into the room.

**Before bringing any of these programs into a real exam, you MUST verify your specific exam's
calculator and program policy with your instructor or exam administrator.** These tools are
intended strictly as **study and practice aids** for homework, practice exams, and self-review —
they are **not** intended to help with, and must not be used to facilitate, cheating or misconduct
on a live/proctored exam. When in doubt, delete or archive these programs (or reset your
calculator to defaults) before any exam where their presence would violate the rules.
