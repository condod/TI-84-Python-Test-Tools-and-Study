# Algebra / Linear Algebra / Stats Bundle — TI-84 Plus CE Python

6 standalone TI-84 Plus CE **Python Edition** programs for College Algebra, Linear Algebra,
and Intro Statistics/Probability.

## What's Included

| File | What it does |
|---|---|
| `quadratic_solver.py` | Quadratic equation solver with discriminant classification and real/complex roots (`a ± bi`). |
| `quadratic_vertex_analyzer.py` | Derives a quadratic from its vertex plus one other point, then reports vertex/standard form, domain/range, intercepts, and increasing/decreasing behavior. |
| `linear_system_solver.py` | 2x2 or 3x3 linear system solver via Gaussian elimination with partial pivoting. |
| `matrix_toolkit.py` | Matrix add, multiply, determinant, and inverse for 2x2/3x3 matrices you enter. |
| `descriptive_stats.py` | Mean, median, mode, min/max/range, sample & population variance/standard deviation from a data list (up to 90 values). |
| `combinatorics_probability.py` | nPr, nCr, and binomial probability calculator. |

## Installing on Your Calculator (TI Connect™ CE)

1. Download and install **TI Connect™ CE** (free, from Texas Instruments) on your Windows/Mac computer.
2. Connect your TI-84 Plus CE **Python Edition** to your computer with a USB cable.
3. Open TI Connect CE — it should detect your connected calculator in "Calculator Explorer."
4. For each `.py` file in this bundle: drag and drop the file onto the Calculator Explorer window
   (or use **Actions → Send to Calculator**). TI Connect CE automatically converts the `.py` source
   file into the calculator's native Python AppVar format and installs it into the Python App.
5. On the calculator, open the **Python App**, find the program by name in the on-calculator program
   list, and select **Run**.

You can also skip the computer entirely and type any of these programs directly into the
on-calculator Python editor — they're short, plain-text files.

Keep an eye on the ~50 KB / 100-program on-device storage limit; archive or delete programs you're
not actively using to free up space.

## ⚠️ Exam Policy Disclaimer — Read This First

**Many standardized and proctored exams — AP Exams, the FE/PE exams, and many university
midterms/finals — explicitly prohibit calculators that have been loaded with stored notes,
formulas, or "quiz" programs.** Some exams require you to clear your calculator's memory or use
exam mode (e.g. TI's Press-to-Test) before you're allowed to bring it into the room.

**Before bringing any of these programs into a real exam, you MUST verify your specific exam's
calculator and program policy with your instructor or exam administrator.** These tools are
intended strictly as **study and practice aids** for homework, practice exams, and self-review —
they are **not** intended to help with, and must not be used to facilitate, cheating or misconduct
on a live/proctored exam. When in doubt, delete or archive these programs (or reset your
calculator to defaults) before any exam where their presence would violate the rules.
